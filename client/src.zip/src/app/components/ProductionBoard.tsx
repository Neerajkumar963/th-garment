import { Clock, User, AlertCircle, CheckCircle2, Loader2, ArrowRight } from "lucide-react";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { useState, useEffect } from "react";
import { api } from "../../services/api";
import toast from "react-hot-toast";
import { Button } from "./ui/button";
import { Modal } from "./ui/modal";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Label } from "./ui/label";

interface ProcessingJob {
  id: number;
  worker_name: string;
  org_name: string;
  org_dress_name: string;
  sq: any;
  status: string;
  processing_rate: number;
  stage_name: string;
  created_on: string;
  updated_on: string;
  remarks: string;
  order_id: number;
  stage_id: number;
}

interface Stage {
  id: number;
  name: string;
  jobs: ProcessingJob[];
}

function JobCardComponent({
  job,
  onRefresh,
  onMove
}: {
  job: ProcessingJob,
  onRefresh: () => void,
  onMove: (job: ProcessingJob) => void
}) {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleComplete = async () => {
    setIsSubmitting(true);
    try {
      await api.put(`/processing/${job.id}/complete-stage`, {});
      toast.success("Stage completed. Available for next assignment.");
      onRefresh();
    } catch (error: any) {
      toast.error(error.message || "Failed to complete stage");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Parse SQ
  const sq = typeof job.sq === 'string' ? JSON.parse(job.sq) : job.sq;
  const totalPieces = Object.values(sq).reduce((a: any, b: any) => a + (parseInt(b) || 0), 0) as number;

  const isProcessed = job.status === 'processed';

  return (
    <div className={cn(
      "bg-white rounded-lg border-2 p-4 hover:shadow-md transition-shadow relative group",
      isProcessed ? "border-green-100 bg-green-50/20" : "border-gray-200"
    )}>
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex flex-col">
          <span className="font-mono text-[10px] font-bold text-gray-400 uppercase tracking-tighter">Job ID</span>
          <span className="font-bold text-gray-900 leading-none">#{job.id}</span>
        </div>
        <Badge variant="outline" className={cn(
          "text-[10px] h-5 border-gray-200",
          isProcessed ? "bg-green-100 text-green-700 border-green-200" : "text-gray-500"
        )}>
          {isProcessed ? "READY FOR NEXT" : `Order #${job.order_id}`}
        </Badge>
      </div>

      {/* Product Info */}
      <div className="mb-3">
        <h4 className="font-bold text-gray-900 text-sm mb-0.5 truncate">{job.org_name}</h4>
        <p className="text-xs text-gray-600 truncate">{job.org_dress_name}</p>
      </div>

      {/* Size Breakdown Snippet */}
      <div className="grid grid-cols-4 gap-1 mb-4">
        {Object.entries(sq).slice(0, 4).map(([size, qty]) => (
          <div key={size} className="text-center p-1 bg-white/50 rounded border border-gray-100">
            <p className="text-[8px] font-bold text-gray-400 uppercase leading-none">{size}</p>
            <p className="text-[10px] font-bold text-gray-900 leading-none mt-1">{qty as string}</p>
          </div>
        ))}
      </div>

      {/* Worker Info */}
      <div className="flex items-center gap-2 mb-4 p-2 bg-gray-50/50 rounded-lg">
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-50 to-indigo-100 border border-indigo-200 flex items-center justify-center shadow-sm">
          <User className="w-4 h-4 text-indigo-600" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-bold text-gray-900 text-[11px] truncate leading-none mb-1">{job.worker_name}</p>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-bold text-gray-400 bg-white px-1.5 py-0.5 rounded border border-gray-100">₹{job.processing_rate}/pc</span>
            <span className="text-[10px] text-gray-500">• {totalPieces} items</span>
          </div>
        </div>
      </div>

      {/* Action */}
      {isProcessed ? (
        <Button
          size="sm"
          className="w-full h-8 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm"
          onClick={() => onMove(job)}
          disabled={job.stage_id >= 7}
        >
          {job.stage_id >= 7 ? "Production Complete" : (
            <>
              <ArrowRight className="w-3 h-3 mr-2" />
              Assign Stage {job.stage_id + 1}
            </>
          )}
        </Button>
      ) : (
        <Button
          size="sm"
          className="w-full h-8 text-xs font-bold bg-green-600 hover:bg-green-700 text-white shadow-sm"
          onClick={handleComplete}
          disabled={isSubmitting}
        >
          {isSubmitting ? <Loader2 className="w-3 h-3 animate-spin mr-2" /> : <CheckCircle2 className="w-3 h-3 mr-2" />}
          Complete Stage
        </Button>
      )}

      {/* Footer Meta */}
      <div className="mt-3 pt-3 border-t border-gray-50 flex items-center justify-between text-[9px] text-gray-400">
        <span className="flex items-center gap-1">
          <Clock className="w-2.5 h-2.5" />
          {new Date(job.created_on).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </span>
        <span className="font-bold uppercase tracking-widest text-indigo-300">{job.stage_name}</span>
      </div>
    </div>
  );
}

export function ProductionBoard() {
  const [stages, setStages] = useState<Stage[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAssignPanel, setShowAssignPanel] = useState(false);
  const [employees, setEmployees] = useState<any[]>([]);
  const [availableStock, setAvailableStock] = useState<any[]>([]);

  // Transition Modal State
  const [transitionJob, setTransitionJob] = useState<ProcessingJob | null>(null);
  const [selectedEmpId, setSelectedEmpId] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchBoard = async () => {
    try {
      const data = await api.get('/processing/board');
      setStages(data.stages || []);
    } catch (error) {
      toast.error("Failed to load production board");
    } finally {
      setLoading(false);
    }
  };

  const fetchHelpers = async () => {
    try {
      const empData = await api.get('/employees');
      setEmployees(empData.employees || []);

      const cuttingData = await api.get('/cutting');
      setAvailableStock(cuttingData.jobs?.filter((j: any) => j.status === 'Completed') || []);
    } catch (error) {
      console.error("Failed to load helper data");
    }
  };

  useEffect(() => {
    fetchBoard();
    fetchHelpers();
  }, []);

  const handleAssign = async (stockId: number, empId: number, stageId: number, rate: number, sq: any) => {
    setIsSubmitting(true);
    try {
      await api.post('/processing/assign', {
        cut_stock_id: stockId,
        emp_id: empId,
        stage_id: stageId,
        sq: sq,
        processing_rate: rate
      });
      toast.success("Worker assigned to floor");
      setTransitionJob(null);
      setSelectedEmpId("");
      fetchBoard();
    } catch (error: any) {
      toast.error(error.message || "Assignment failed");
    } finally {
      setIsSubmitting(false);
    }
  };

  const totalActive = stages.reduce((acc, stage) => acc + stage.jobs.length, 0);

  return (
    <div className="flex-1 overflow-hidden bg-[#f8fafc] flex flex-col">
      {/* Dynamic Header */}
      <div className="bg-white border-b border-gray-200 px-8 py-5 flex items-center justify-between shadow-sm z-10">
        <div>
          <h1 className="text-2xl font-black text-gray-900 flex items-center gap-3">
            <div className="p-2 bg-indigo-600 rounded-lg">
              <ArrowRight className="w-5 h-5 text-white" />
            </div>
            Production Floor
          </h1>
          <p className="text-xs font-bold text-gray-500 mt-1 uppercase tracking-widest">
            Real-time stage tracking • <span className="text-indigo-600">{totalActive} Jobs Active</span>
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" size="sm" onClick={fetchBoard} className="text-xs h-9">
            Refresh Board
          </Button>
          <Button
            className="bg-[#e94560] hover:bg-[#d13a52] text-xs h-9 font-bold px-6"
            onClick={() => setShowAssignPanel(!showAssignPanel)}
          >
            {showAssignPanel ? "Close Assignment" : "Assign New Processing"}
          </Button>
        </div>
      </div>

      {/* New Assignment Panel */}
      {showAssignPanel && (
        <div className="bg-white border-b border-gray-200 p-6 animate-in slide-in-from-top duration-300">
          <h3 className="text-sm font-bold text-gray-900 mb-4 uppercase tracking-widest">Available Stock for Processing</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {availableStock.length === 0 ? (
              <p className="text-xs text-gray-500 italic px-2">No completed cutting jobs available for assignment.</p>
            ) : (
              availableStock.map(stock => (
                <div key={stock.id} className="p-4 border border-gray-100 rounded-xl bg-gray-50 hover:border-indigo-200 transition-colors">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[10px] font-bold text-gray-400 uppercase">Stock ID #{stock.id}</span>
                    <Badge className="bg-green-100 text-green-700 text-[9px]">Ready</Badge>
                  </div>
                  <p className="font-bold text-gray-900 text-sm mb-1">{stock.org_name}</p>
                  <p className="text-xs text-gray-500 mb-4">{stock.org_dress_name}</p>

                  <div className="flex gap-2">
                    <select
                      className="flex-1 h-8 text-[11px] rounded border-gray-200 bg-white px-2 focus:ring-1 focus:ring-indigo-500 font-bold"
                      id={`emp-${stock.id}`}
                    >
                      <option value="">Select Worker</option>
                      {employees.map(e => <option key={e.id} value={e.id}>{e.name} ({e.role_name})</option>)}
                    </select>
                    <Button
                      size="sm"
                      className="h-8 text-[11px] px-3 bg-indigo-600 hover:bg-indigo-700 font-bold"
                      onClick={() => {
                        const empId = (document.getElementById(`emp-${stock.id}`) as HTMLSelectElement).value;
                        if (!empId) return toast.error("Select a worker");
                        // Stage 1 (FR) hardcoded for now
                        handleAssign(stock.id, parseInt(empId), 1, 10, stock.sq);
                      }}
                    >
                      Assign to FR
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Kanban Board */}
      <div className="flex-1 overflow-x-auto p-6 flex gap-6">
        {loading ? (
          <div className="min-w-full flex items-center justify-center py-20">
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="w-10 h-10 animate-spin text-indigo-600" />
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Loading Floor Data...</p>
            </div>
          </div>
        ) : stages.length === 0 ? (
          <div className="min-w-full flex items-center justify-center py-20 bg-white/50 rounded-2xl border-2 border-dashed border-gray-200">
            <p className="text-gray-400 font-bold uppercase tracking-widest">Floor is empty. Assign workers to start.</p>
          </div>
        ) : (
          stages.map((stage) => (
            <div key={stage.id} className="flex-shrink-0 w-[300px] flex flex-col h-full">
              {/* Column Header */}
              <div className="mb-4 flex items-center justify-between px-1">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.5)]" />
                  <h3 className="font-bold text-gray-800 text-xs uppercase tracking-wider">
                    {stage.name}
                  </h3>
                </div>
                <Badge variant="secondary" className="bg-white text-gray-600 border-gray-100 text-[10px] h-5 px-2">
                  {stage.jobs.length}
                </Badge>
              </div>

              {/* Cards Container */}
              <div className="flex-1 bg-gray-100/30 rounded-xl p-3 space-y-4 overflow-y-auto border border-gray-200/50 hover:bg-gray-100/50 transition-colors scrollbar-hide">
                {stage.jobs.length > 0 ? (
                  stage.jobs.map((job) => (
                    <JobCardComponent
                      key={job.id}
                      job={job}
                      onRefresh={fetchBoard}
                      onMove={(job) => setTransitionJob(job)}
                    />
                  ))
                ) : (
                  <div className="border-2 border-dashed border-gray-200 rounded-lg p-8 flex flex-col items-center justify-center text-center opacity-40">
                    <User className="w-8 h-8 text-gray-300 mb-2" />
                    <p className="text-[10px] font-bold text-gray-400 uppercase">Wait for assignment</p>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Assignment/Transition Modal */}
      <Modal
        isOpen={!!transitionJob}
        onClose={() => setTransitionJob(null)}
        title={`Assign Next Stage: Stage ${transitionJob ? transitionJob.stage_id + 1 : ''}`}
        size="md"
      >
        {transitionJob && (
          <div className="space-y-6">
            <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-100">
              <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">In-Transition Job</p>
              <h3 className="font-bold text-gray-900">{transitionJob.org_name}</h3>
              <p className="text-sm text-gray-600">{transitionJob.org_dress_name}</p>
              <div className="mt-3 flex gap-2">
                <Badge className="bg-white text-indigo-600 border-indigo-100 font-bold uppercase text-[9px]">
                  Stage {transitionJob.stage_id} Complete
                </Badge>
                <Badge className="bg-indigo-600 text-white font-bold uppercase text-[9px]">
                  Moving to Stage {transitionJob.stage_id + 1}
                </Badge>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Select Next Worker</Label>
              <Select onValueChange={(val) => setSelectedEmpId(val)}>
                <SelectTrigger className="h-12 border-gray-100 bg-gray-50/50 rounded-xl font-bold">
                  <SelectValue placeholder="Search worker catalog..." />
                </SelectTrigger>
                <SelectContent>
                  {employees.map(emp => (
                    <SelectItem key={emp.id} value={emp.id.toString()}>
                      {emp.name} ({emp.role_name})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Processing Rate (per piece)</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 font-bold text-gray-400 text-sm">₹</span>
                <Input
                  id="trans-rate"
                  type="number"
                  defaultValue={transitionJob.processing_rate}
                  className="pl-7 h-12 bg-gray-50/50 border-gray-100 rounded-xl font-bold"
                />
              </div>
            </div>

            <div className="pt-6 border-t border-gray-100 flex gap-3">
              <Button variant="ghost" className="flex-1 font-bold" onClick={() => setTransitionJob(null)}>Cancel</Button>
              <Button
                className="flex-[2] bg-indigo-600 hover:bg-indigo-700 font-bold"
                onClick={() => {
                  const rate = (document.getElementById('trans-rate') as HTMLInputElement).value;
                  handleAssign(
                    transitionJob.cut_stock_id,
                    parseInt(selectedEmpId),
                    transitionJob.stage_id + 1,
                    parseFloat(rate),
                    transitionJob.sq
                  );
                }}
                disabled={isSubmitting || !selectedEmpId}
              >
                {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Authorize Assignment"}
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div >
  );
}

