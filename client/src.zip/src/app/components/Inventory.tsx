import { Search, Plus, Edit, Trash2, AlertCircle, Loader2, Package, Layers } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { useState, useEffect } from "react";
import { api } from "../../services/api";
import toast from "react-hot-toast";
import { Modal } from "./ui/modal";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

interface FabricItem {
  id: number;
  cloth_type: string;
  color_name: string;
  design_name: string;
  quality_name: string;
  total_quantity: number;
  roll_count: number;
  status: "in" | "low" | "out";
  updated_on: string;
}

interface SellingStockItem {
  org_dress_id: number;
  org_dress_name: string;
  org_name: string;
  size: string;
  price: number;
  available_qty: number;
}

export function Inventory() {
  const [view, setView] = useState<"fabric" | "finished">("fabric");
  const [fabrics, setFabrics] = useState<FabricItem[]>([]);
  const [finishedStock, setFinishedStock] = useState<SellingStockItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  // Add Fabric Modal state
  const [isAddFabricModalOpen, setIsAddFabricModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [metadata, setMetadata] = useState<{
    clothTypes: any[];
    colors: any[];
    designs: any[];
    qualities: any[];
  }>({ clothTypes: [], colors: [], designs: [], qualities: [] });

  const [fabricForm, setFabricForm] = useState({
    clothType: "",
    colorName: "",
    designName: "",
    qualityName: "",
    rolls: [] as number[]
  });

  const fetchMetadata = async () => {
    try {
      const [ct, c, d, q] = await Promise.all([
        api.get('/fabric/cloth-types'),
        api.get('/fabric/colors'),
        api.get('/fabric/designs'),
        api.get('/fabric/qualities')
      ]);
      setMetadata({ clothTypes: ct, colors: c, designs: d, qualities: q });
    } catch (error) {
      console.error("Failed to fetch metadata", error);
    }
  };

  const handleAddFabric = async () => {
    if (!fabricForm.clothType || !fabricForm.colorName || !fabricForm.designName || !fabricForm.qualityName) {
      return toast.error("Please fill all required fields");
    }
    if (fabricForm.rolls.length === 0) {
      return toast.error("Please add at least one roll");
    }

    setIsSubmitting(true);
    try {
      await api.post('/fabric', fabricForm);
      toast.success("Fabric and rolls added successfully!");
      setIsAddFabricModalOpen(false);
      setFabricForm({ clothType: "", colorName: "", designName: "", qualityName: "", rolls: [] });
      fetchData();
    } catch (error: any) {
      toast.error(error.message || "Failed to add fabric");
    } finally {
      setIsSubmitting(false);
    }
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      if (view === "fabric") {
        const data = await api.get('/fabric');
        setFabrics(data.fabrics || []);
      } else {
        const data = await api.get('/sales/stock');
        setFinishedStock(data.stock || []);
      }
    } catch (error) {
      toast.error("Failed to load inventory data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    if (view === "fabric") fetchMetadata();
  }, [view]);

  // Filtering
  const filteredFabrics = fabrics.filter(f =>
    f.cloth_type.toLowerCase().includes(searchQuery.toLowerCase()) ||
    f.color_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    f.design_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredFinished = finishedStock.filter(s =>
    s.org_dress_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.org_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex-1 overflow-auto bg-[#f8fafc]">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-8 py-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-black text-gray-900">Inventory Master</h1>
            <p className="text-sm font-bold text-gray-500 mt-1 uppercase tracking-widest">
              {view === "fabric" ? "Raw Material: Fabric & Rolls" : "Finished Goods: Ready for Sale"}
            </p>
          </div>
          <div className="flex gap-3">
            <div className="flex bg-gray-100 p-1 rounded-lg">
              <Button
                variant={view === "fabric" ? "default" : "ghost"}
                size="sm"
                onClick={() => setView("fabric")}
                className={`text-xs px-4 ${view === "fabric" ? "bg-white text-indigo-600 shadow-sm hover:bg-white" : "text-gray-500"}`}
              >
                <Layers className="w-3 h-3 mr-2" /> Fabric
              </Button>
              <Button
                variant={view === "finished" ? "default" : "ghost"}
                size="sm"
                onClick={() => setView("finished")}
                className={`text-xs px-4 ${view === "finished" ? "bg-white text-indigo-600 shadow-sm hover:bg-white" : "text-gray-500"}`}
              >
                <Package className="w-3 h-3 mr-2" /> Finished
              </Button>
            </div>
            <Button
              className="bg-[#e94560] hover:bg-[#d13a52] text-xs font-bold px-6"
              onClick={() => setIsAddFabricModalOpen(true)}
            >
              <Plus className="w-4 h-4 mr-2" /> Add {view === "fabric" ? "Fabric" : "Stock"}
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-md transition-shadow">
            <p className="text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Total SKU</p>
            <p className="text-3xl font-black text-gray-900">
              {view === "fabric" ? fabrics.length : finishedStock.length}
            </p>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-md transition-shadow">
            <p className="text-xs font-black uppercase tracking-widest text-gray-400 mb-2">
              {view === "fabric" ? "Total Meters" : "Total Ready"}
            </p>
            <p className="text-3xl font-black text-indigo-600">
              {view === "fabric"
                ? fabrics.reduce((a, b) => a + Number(b.total_quantity), 0).toFixed(1)
                : finishedStock.reduce((a, b) => a + Number(b.available_qty), 0)}
              <span className="text-sm font-bold ml-1">{view === "fabric" ? "m" : "pcs"}</span>
            </p>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
            <p className="text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Critical Stock</p>
            <p className="text-3xl font-black text-rose-500">
              {view === "fabric"
                ? fabrics.filter(f => f.status !== 'in').length
                : finishedStock.filter(s => s.available_qty < 10).length}
            </p>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
            <p className="text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Storage Status</p>
            <Badge className="bg-green-100 text-green-700 font-black border-green-200">OPTIMAL</Badge>
          </div>
        </div>

        {/* Search */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm mb-6 p-4">
          <div className="flex items-center gap-4">
            <div className="flex-1 relative">
              <Search className="w-4 h-4 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2" />
              <Input
                placeholder={`Search ${view === "fabric" ? "cloth type, color or design..." : "dress or client..."}`}
                className="pl-11 h-12 border-none bg-gray-50 focus:bg-white transition-all font-medium placeholder:text-gray-400"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50/50 border-b border-gray-100">
                <tr>
                  {view === "fabric" ? (
                    <>
                      <th className="px-8 py-5 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Fabric Specs</th>
                      <th className="px-8 py-5 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Stock Level</th>
                      <th className="px-8 py-5 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Rolls</th>
                      <th className="px-8 py-5 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Status</th>
                      <th className="px-8 py-5 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Updated</th>
                    </>
                  ) : (
                    <>
                      <th className="px-8 py-5 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Product / Dress</th>
                      <th className="px-8 py-5 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Client</th>
                      <th className="px-8 py-5 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Size</th>
                      <th className="px-8 py-5 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Quantity</th>
                      <th className="px-8 py-5 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">MRP</th>
                    </>
                  )}
                  <th className="px-8 py-5 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {loading ? (
                  <tr>
                    <td colSpan={6} className="py-20 text-center">
                      <div className="flex flex-col items-center gap-3">
                        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
                        <span className="text-xs font-bold text-gray-400 uppercase">Synchronizing...</span>
                      </div>
                    </td>
                  </tr>
                ) : view === "fabric" ? (
                  filteredFabrics.map((f) => (
                    <tr key={f.id} className="hover:bg-gray-50/50 transition-colors group">
                      <td className="px-8 py-5">
                        <div>
                          <p className="font-bold text-gray-900 text-sm">{f.cloth_type} • {f.quality_name}</p>
                          <p className="text-xs text-gray-500 mt-0.5">{f.color_name} / {f.design_name}</p>
                        </div>
                      </td>
                      <td className="px-8 py-5">
                        <div className="flex items-center gap-2">
                          <p className="text-lg font-black text-gray-900 font-mono">{f.total_quantity}</p>
                          <span className="text-[10px] font-black text-gray-400">METERS</span>
                        </div>
                      </td>
                      <td className="px-8 py-5">
                        <Badge variant="outline" className="border-gray-200 text-gray-500 font-bold">{f.roll_count} Rolls</Badge>
                      </td>
                      <td className="px-8 py-5">
                        <Badge
                          className={`font-black uppercase tracking-tighter text-[10px] ${f.status === 'in' ? 'bg-green-50 text-green-600' :
                            f.status === 'low' ? 'bg-yellow-50 text-yellow-600' : 'bg-red-50 text-red-600'
                            }`}
                        >
                          {f.status === 'in' ? 'Available' : f.status === 'low' ? 'Low Stock' : 'Out of Stock'}
                        </Badge>
                      </td>
                      <td className="px-8 py-5 text-xs font-bold text-gray-400">
                        {new Date(f.updated_on).toLocaleDateString()}
                      </td>
                      <td className="px-8 py-5">
                        <div className="flex gap-2">
                          <Button size="icon" variant="ghost" className="h-8 w-8 hover:bg-gray-100 text-gray-400 hover:text-indigo-600 transition-colors">
                            <Edit className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  filteredFinished.map((s, idx) => (
                    <tr key={idx} className="hover:bg-gray-50/50 transition-colors group">
                      <td className="px-8 py-5">
                        <p className="font-bold text-gray-900 text-sm">{s.org_dress_name}</p>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">SKU#{s.org_dress_id}</p>
                      </td>
                      <td className="px-8 py-5 text-xs font-bold text-gray-600">{s.org_name}</td>
                      <td className="px-8 py-5">
                        <Badge variant="outline" className="text-indigo-600 border-indigo-100 bg-indigo-50/50 font-black">{s.size}</Badge>
                      </td>
                      <td className="px-8 py-5">
                        <div className="flex items-center gap-2">
                          <span className="text-lg font-black text-gray-900">{s.available_qty}</span>
                          <span className="text-[9px] font-black text-gray-400 uppercase">PCS</span>
                        </div>
                      </td>
                      <td className="px-8 py-5 text-sm font-black text-indigo-600">₹{s.price}</td>
                      <td className="px-8 py-5">
                        <Button size="icon" variant="ghost" className="h-8 w-8 text-gray-400">
                          <Edit className="w-4 h-4" />
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add Fabric Modal */}
      <Modal
        isOpen={isAddFabricModalOpen}
        onClose={() => setIsAddFabricModalOpen(false)}
        title="Register New Fabric Entry"
        size="lg"
      >
        <div className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Cloth Type</Label>
              <Select onValueChange={(val) => setFabricForm({ ...fabricForm, clothType: val })}>
                <SelectTrigger className="h-12 border-gray-100 bg-gray-50/50 rounded-xl font-bold">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {metadata.clothTypes.map(t => <SelectItem key={t.id} value={t.type}>{t.type}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Color Variant</Label>
              <Select onValueChange={(val) => setFabricForm({ ...fabricForm, colorName: val })}>
                <SelectTrigger className="h-12 border-gray-100 bg-gray-50/50 rounded-xl font-bold">
                  <SelectValue placeholder="Select color" />
                </SelectTrigger>
                <SelectContent>
                  {metadata.colors.map(c => <SelectItem key={c.id} value={c.color_name}>{c.color_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Design Pattern</Label>
              <Select onValueChange={(val) => setFabricForm({ ...fabricForm, designName: val })}>
                <SelectTrigger className="h-12 border-gray-100 bg-gray-50/50 rounded-xl font-bold">
                  <SelectValue placeholder="Select design" />
                </SelectTrigger>
                <SelectContent>
                  {metadata.designs.map(d => <SelectItem key={d.id} value={d.design_name}>{d.design_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Fabric Quality</Label>
              <Select onValueChange={(val) => setFabricForm({ ...fabricForm, qualityName: val })}>
                <SelectTrigger className="h-12 border-gray-100 bg-gray-50/50 rounded-xl font-bold">
                  <SelectValue placeholder="Select quality" />
                </SelectTrigger>
                <SelectContent>
                  {metadata.qualities.map(q => <SelectItem key={q.id} value={q.quality_name}>{q.quality_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Roll Breakdown (Meters)</Label>
              <Button
                variant="outline"
                size="sm"
                className="h-8 text-[10px] font-black uppercase tracking-wider border-indigo-100 text-indigo-600 hover:bg-indigo-50"
                onClick={() => setFabricForm({ ...fabricForm, rolls: [...fabricForm.rolls, 0] })}
              >
                + Add Roll
              </Button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {fabricForm.rolls.map((roll, idx) => (
                <div key={idx} className="relative group">
                  <Input
                    type="number"
                    value={roll || ''}
                    className="h-12 bg-gray-50/30 border-gray-100 rounded-xl font-mono font-bold pl-3 pr-8"
                    placeholder="0.00"
                    onChange={(e) => {
                      const newRolls = [...fabricForm.rolls];
                      newRolls[idx] = parseFloat(e.target.value);
                      setFabricForm({ ...fabricForm, rolls: newRolls });
                    }}
                  />
                  <button
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-rose-400 hover:text-rose-600 p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => {
                      const newRolls = fabricForm.rolls.filter((_, i) => i !== idx);
                      setFabricForm({ ...fabricForm, rolls: newRolls });
                    }}
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              ))}
              {fabricForm.rolls.length === 0 && (
                <div className="col-span-full py-8 border-2 border-dashed border-gray-100 rounded-2xl flex flex-col items-center justify-center bg-gray-50/50">
                  <Package className="w-6 h-6 text-gray-300 mb-2" />
                  <p className="text-[10px] font-bold text-gray-400 uppercase">No rolls added yet</p>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between pt-6 border-t border-gray-100 italic text-[10px] text-gray-400 font-medium">
            <p>All rolls will be tracked individually in the master ledger.</p>
            <div className="flex gap-3">
              <Button variant="ghost" className="font-bold text-xs" onClick={() => setIsAddFabricModalOpen(false)}>Cancel</Button>
              <Button
                className="bg-indigo-600 hover:bg-indigo-700 text-xs font-bold px-8 shadow-lg shadow-indigo-100"
                onClick={handleAddFabric}
                disabled={isSubmitting}
              >
                {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Verify & Save Inventory"}
              </Button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}

