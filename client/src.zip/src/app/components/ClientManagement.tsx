import { useState, useEffect } from "react";
import { Search, Phone, Mail, MapPin, Building2, Plus, DollarSign, Package, TrendingUp, Loader2, ArrowRightLeft, Edit } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { cn } from "./ui/utils";
import { api } from "../../services/api";
import toast from "react-hot-toast";
import { Modal } from "./ui/modal";
import { Label } from "./ui/label";

interface Client {
  id: number;
  org_name: string;
  name: string;
  phone: string;
  email: string;
  org_type: string;
  current_balance: number;
  branch?: string;
}

interface Product {
  id: number;
  org_dress_name: string;
  item_name: string;
  color_name: string;
  material_req: number;
  processing_rate: number;
  prices: { size: string, price: number }[];
}

interface LedgerEntry {
  id: number;
  datetime: string;
  transaction: 'DR' | 'CR';
  mode: string;
  description: string;
  debit: number;
  credit: number;
  amount: number;
  remarks?: string;
  balance: number;
}

export function ClientManagement() {
  const [clients, setClients] = useState<Client[]>([]);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [detailLoading, setDetailLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  // Add Client Modal state
  const [isAddClientModalOpen, setIsAddClientModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [clientForm, setClientForm] = useState({
    name: "",
    org_name: "",
    phone: "",
    email: "",
    gstin: "",
    adhaar: "",
    branch: "",
    org_type: "Retail"
  });

  const handleAddClient = async () => {
    if (!clientForm.org_name || !clientForm.phone) {
      return toast.error("Organization name and phone are required");
    }

    setIsSubmitting(true);
    try {
      await api.post('/clients', clientForm);
      toast.success("New client relationship established!");
      setIsAddClientModalOpen(false);
      setClientForm({ name: "", org_name: "", phone: "", email: "", gstin: "", adhaar: "", branch: "", org_type: "Retail" });
      fetchClients();
    } catch (error: any) {
      toast.error(error.message || "Failed to add client");
    } finally {
      setIsSubmitting(false);
    }
  };

  const fetchClients = async () => {
    try {
      const data = await api.get('/clients');
      setClients(data.clients || []);
      if (data.clients?.length > 0 && !selectedClient) {
        setSelectedClient(data.clients[0]);
      }
    } catch (error) {
      toast.error("Failed to load clients");
    } finally {
      setLoading(false);
    }
  };

  const fetchDetails = async (clientId: number) => {
    setDetailLoading(true);
    try {
      const [prodRes, ledgerRes] = await Promise.all([
        api.get(`/clients/${clientId}/products`),
        api.get(`/clients/${clientId}/account`)
      ]);
      setProducts(prodRes.products || []);
      setLedger(ledgerRes.ledger || []);
    } catch (error) {
      toast.error("Failed to load client details");
    } finally {
      setDetailLoading(false);
    }
  };

  useEffect(() => {
    fetchClients();
  }, []);

  useEffect(() => {
    if (selectedClient) {
      fetchDetails(selectedClient.id);
    }
  }, [selectedClient?.id]);

  const filteredClients = clients.filter(c =>
    c.org_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex-1 overflow-auto bg-[#f8fafc]">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-8 py-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-black text-gray-900">CRM & Accounts</h1>
            <p className="text-sm font-bold text-gray-500 mt-1 uppercase tracking-widest">Manage clients, price lists and payment ledgers</p>
          </div>
          <Button
            className="bg-[#e94560] hover:bg-[#d13a52] font-bold px-6"
            onClick={() => setIsAddClientModalOpen(true)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add New Client
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="flex h-[calc(100vh-140px)]">
        {/* Left Sidebar - Client List */}
        <div className="w-96 bg-white border-r border-gray-200 flex flex-col">
          {/* Search */}
          <div className="p-4 border-b border-gray-200">
            <div className="relative">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <Input
                placeholder="Search clients..."
                className="pl-9 h-11 border-gray-100 bg-gray-50 focus:bg-white"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          {/* Client List */}
          <div className="flex-1 overflow-y-auto">
            {loading ? (
              <div className="py-20 text-center flex flex-col items-center gap-2">
                <Loader2 className="w-6 h-6 animate-spin text-indigo-600" />
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Syncing CRM...</span>
              </div>
            ) : filteredClients.length === 0 ? (
              <p className="py-20 text-center text-xs font-bold text-gray-400 uppercase">No clients found</p>
            ) : (
              filteredClients.map((client) => (
                <div
                  key={client.id}
                  onClick={() => setSelectedClient(client)}
                  className={cn(
                    "p-5 border-b border-gray-50 cursor-pointer transition-all hover:bg-indigo-50/30",
                    selectedClient?.id === client.id && "bg-indigo-50 border-l-4 border-l-indigo-600 shadow-sm"
                  )}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-bold text-gray-900 text-sm">{client.org_name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className="text-[9px] uppercase font-black bg-white border-gray-100">
                          {client.org_type || 'General'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-[10px] font-bold text-gray-400 uppercase">Balance</span>
                    <span
                      className={cn(
                        "text-sm font-black",
                        client.current_balance >= 0 ? "text-green-600" : "text-rose-600"
                      )}
                    >
                      ₹{Math.abs(client.current_balance).toLocaleString()}
                      {client.current_balance < 0 && <span className="text-[10px] ml-1">DR</span>}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Panel - Client Details */}
        <div className="flex-1 overflow-y-auto bg-[#f8fafc]">
          {selectedClient ? (
            <div className="p-8 max-w-6xl mx-auto space-y-6">
              {/* Client Header */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
                <div className="flex items-start justify-between mb-8">
                  <div className="flex items-center gap-6">
                    <div className="w-16 h-16 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-200">
                      <Building2 className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <h2 className="text-2xl font-black text-gray-900">{selectedClient.org_name}</h2>
                      <div className="flex items-center gap-3 mt-1">
                        <Badge className="bg-indigo-50 text-indigo-600 border-indigo-100 font-bold uppercase text-[10px]">
                          {selectedClient.org_type}
                        </Badge>
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">ID #{selectedClient.id}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="font-bold h-9 bg-gray-50 border-gray-200">Edit Info</Button>
                    <Button variant="outline" size="sm" className="font-bold h-9 bg-gray-50 border-gray-200">New Product</Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div className="space-y-4">
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest border-b border-gray-50 pb-2">Contact Details</p>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3 text-sm font-bold text-gray-700">
                        <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center"><Phone className="w-4 h-4 text-indigo-600" /></div>
                        <span>{selectedClient.phone}</span>
                      </div>
                      <div className="flex items-center gap-3 text-sm font-bold text-gray-700">
                        <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center"><Mail className="w-4 h-4 text-indigo-600" /></div>
                        <span className="truncate">{selectedClient.email || 'N/A'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest border-b border-gray-50 pb-2">Business Terms</p>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3 text-sm font-bold text-gray-700">
                        <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center"><TrendingUp className="w-4 h-4 text-indigo-600" /></div>
                        <span>{selectedClient.org_type} Pricing</span>
                      </div>
                      <div className="flex items-center gap-3 text-sm font-bold text-gray-700">
                        <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center"><Package className="w-4 h-4 text-indigo-600" /></div>
                        <span>{products.length} Products Linked</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest border-b border-gray-50 pb-2">Account Summary</p>
                    <div className="p-4 bg-indigo-600 rounded-2xl shadow-lg shadow-indigo-100 relative overflow-hidden group">
                      <DollarSign className="absolute -right-4 -bottom-4 w-24 h-24 text-white/10 group-hover:scale-110 transition-transform" />
                      <p className="text-[9px] font-black text-indigo-100 uppercase tracking-widest mb-1">Current Balance</p>
                      <p className="text-2xl font-black text-white">₹{Math.abs(selectedClient.current_balance).toLocaleString()}</p>
                      <p className="text-[10px] font-bold text-indigo-200 mt-1">
                        {selectedClient.current_balance >= 0 ? "SURPLUS / ADVANCE" : "OUTSTANDING DUE"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Product Catalog */}
                <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-md font-black text-gray-900 uppercase tracking-widest flex items-center gap-2">
                      <Package className="w-4 h-4 text-indigo-600" /> Product Matrix
                    </h3>
                    <Badge className="bg-gray-100 text-gray-500 font-bold border-none">{products.length}</Badge>
                  </div>
                  <div className="space-y-3">
                    {detailLoading ? <Loader2 className="w-6 h-6 animate-spin mx-auto my-10 text-indigo-200" /> :
                      products.length === 0 ? <p className="text-center py-10 text-xs font-bold text-gray-400 uppercase">No products configured</p> :
                        products.map((product) => (
                          <div key={product.id} className="p-4 rounded-xl border border-gray-50 bg-gray-50/50 hover:bg-white hover:border-indigo-100 hover:shadow-md transition-all group">
                            <div className="flex justify-between items-start">
                              <div>
                                <p className="font-bold text-gray-900">{product.org_dress_name}</p>
                                <p className="text-[10px] font-bold text-gray-400 mt-0.5">{product.item_name} • {product.color_name}</p>
                              </div>
                              <Button size="icon" variant="ghost" className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"><Edit className="w-3 h-3" /></Button>
                            </div>
                            <div className="grid grid-cols-3 gap-2 mt-4">
                              {product.prices?.map((p, idx) => (
                                <div key={idx} className="bg-white p-2 rounded-lg border border-gray-100 text-center">
                                  <p className="text-[8px] font-black text-gray-400 uppercase">{p.size}</p>
                                  <p className="text-xs font-black text-indigo-600">₹{p.price}</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                  </div>
                </div>

                {/* Account Ledger */}
                <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 flex flex-col">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-md font-black text-gray-900 uppercase tracking-widest flex items-center gap-2">
                      <ArrowRightLeft className="w-4 h-4 text-indigo-600" /> Recent Ledger
                    </h3>
                    <Button variant="link" className="text-xs font-bold text-indigo-600 px-0 h-auto">View Full Statement</Button>
                  </div>
                  <div className="flex-1 space-y-4">
                    {detailLoading ? <Loader2 className="w-6 h-6 animate-spin mx-auto my-10 text-indigo-200" /> :
                      ledger.length === 0 ? <p className="text-center py-10 text-xs font-bold text-gray-400 uppercase">No transaction history</p> :
                        ledger.map((entry) => (
                          <div key={entry.id} className="flex items-center justify-between p-3 border-b border-gray-50 last:border-0 hover:bg-gray-50/50 rounded-lg transition-colors">
                            <div className="space-y-0.5">
                              <p className="text-sm font-bold text-gray-800">{entry.description || entry.remarks || 'No description'}</p>
                              <p className="text-[10px] font-bold text-gray-400 capitalize">{new Date(entry.datetime).toLocaleDateString()} • {entry.mode}</p>
                            </div>
                            <div className="text-right">
                              <p className={cn(
                                "text-sm font-black",
                                entry.transaction === 'DR' ? "text-rose-600" : "text-green-600"
                              )}>
                                {entry.transaction === 'DR' ? `-₹${entry.amount}` : `+₹${entry.amount}`}
                              </p>
                              <p className="text-[9px] font-bold text-gray-400">Bal: ₹{entry.balance}</p>
                            </div>
                          </div>
                        ))}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center opacity-40">
              <Building2 className="w-20 h-20 text-indigo-200 mb-4" />
              <p className="text-sm font-black text-gray-400 uppercase tracking-widest">Select a client to manage</p>
            </div>
          )}
        </div>
      </div>

      {/* Add Client Modal */}
      <Modal
        isOpen={isAddClientModalOpen}
        onClose={() => setIsAddClientModalOpen(false)}
        title="Onboard New Corporate Client"
        size="lg"
      >
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Organization Name *</Label>
              <Input
                value={clientForm.org_name}
                onChange={(e) => setClientForm({ ...clientForm, org_name: e.target.value })}
                placeholder="Business Entity Name"
                className="h-12 border-gray-100 bg-gray-50/50 rounded-xl font-bold"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Primary Contact Person</Label>
              <Input
                value={clientForm.name}
                onChange={(e) => setClientForm({ ...clientForm, name: e.target.value })}
                placeholder="Full Name"
                className="h-12 border-gray-100 bg-gray-50/50 rounded-xl font-bold"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Phone Number *</Label>
              <Input
                value={clientForm.phone}
                onChange={(e) => setClientForm({ ...clientForm, phone: e.target.value })}
                placeholder="+91 XXXXX XXXXX"
                className="h-12 border-gray-100 bg-gray-50/50 rounded-xl font-bold"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Email Address</Label>
              <Input
                value={clientForm.email}
                onChange={(e) => setClientForm({ ...clientForm, email: e.target.value })}
                placeholder="contact@business.com"
                className="h-12 border-gray-100 bg-gray-50/50 rounded-xl font-bold"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-gray-400">GSTIN / Tax ID</Label>
              <Input
                value={clientForm.gstin}
                onChange={(e) => setClientForm({ ...clientForm, gstin: e.target.value })}
                placeholder="22AAAAA0000A1Z5"
                className="h-12 border-gray-100 bg-gray-50/50 rounded-xl font-mono"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Aadhaar / KYC ID</Label>
              <Input
                value={clientForm.adhaar}
                onChange={(e) => setClientForm({ ...clientForm, adhaar: e.target.value })}
                placeholder="XXXX XXXX XXXX"
                className="h-12 border-gray-100 bg-gray-50/50 rounded-xl font-mono"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Branch / Location</Label>
              <Input
                value={clientForm.branch}
                onChange={(e) => setClientForm({ ...clientForm, branch: e.target.value })}
                placeholder="Main Campus / City"
                className="h-12 border-gray-100 bg-gray-50/50 rounded-xl font-bold"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Client Category</Label>
              <Input
                value={clientForm.org_type}
                onChange={(e) => setClientForm({ ...clientForm, org_type: e.target.value })}
                placeholder="Retail / Wholesale / Export"
                className="h-12 border-gray-100 bg-gray-50/50 rounded-xl font-bold"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-6 border-t border-gray-100">
            <p className="text-[10px] text-gray-400 italic">Creating a client will automatically initialize their financial ledger.</p>
            <div className="flex gap-3">
              <Button variant="ghost" className="font-bold text-xs" onClick={() => setIsAddClientModalOpen(false)}>Cancel</Button>
              <Button
                className="bg-indigo-600 hover:bg-indigo-700 text-xs font-bold px-8 shadow-lg shadow-indigo-100"
                onClick={handleAddClient}
                disabled={isSubmitting}
              >
                {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Establish Relationship"}
              </Button>
            </div>
          </div>
        </div>
      </Modal>
    </div >
  );
}

